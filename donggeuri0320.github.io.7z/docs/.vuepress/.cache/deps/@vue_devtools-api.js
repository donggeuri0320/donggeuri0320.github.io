import {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
} from "./chunk-UKCZNIRO.js";
export {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
};
//# sourceMappingURL=@vue_devtools-api.js.map
